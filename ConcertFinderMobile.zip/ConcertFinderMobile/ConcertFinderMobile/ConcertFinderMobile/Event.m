//
//  Event.m
//  ConcertFinderMobile
//
//  Created by Samir Houari on 09/07/12.
//  Copyright (c) 2012 Epita. All rights reserved.
//

#import "Event.h"


@implementation Event

@dynamic cp;
@dynamic date_begin;
@dynamic date_end;
@dynamic desc;
@dynamic ev_id;
@dynamic fav;
@dynamic img;
@dynamic latitude;
@dynamic longitude;
@dynamic name;
@dynamic pays;
@dynamic rue;
@dynamic titre;
@dynamic type;
@dynamic ville;

@end
