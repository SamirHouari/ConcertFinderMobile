//
//  TabCOntroller.h
//  ConcertFinderMobile
//
//  Created by Samir Houari on 15/06/12.
//  Copyright (c) 2012 Epita. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TabCOntroller : UITabBarController

@end
