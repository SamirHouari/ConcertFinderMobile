//
//  MasterTabController.m
//  ConcertFinderMobile
//
//  Created by Samir Houari on 15/06/12.
//  Copyright (c) 2012 Epita. All rights reserved.
//

#import "MasterTabController.h"

@implementation MasterTabController : UITabBarController



@end
